import * as React from 'react'
import { PropertyControls, ControlType } from 'framer'

const style: React.CSSProperties = {
  height: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  textAlign: 'center',
  color: '#8855FF',
  background: 'rgba(136, 85, 255, 0.1)',
  overflow: 'hidden',
}

const data = Data({ scale: Animatable(1) })


// Define type of property
interface Props {
  text: string
}

export class SimpleAnimate extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: 'menu',
  }

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: 'Text' },
  }

  componentWillReceiveProps(nextProps) {

    // Play onMouseUp Animation
    if (nextProps.playingOnTap !== this.props.playingOnTap) {
      let left
      let top
      let springOptions = {
        tension: 30
        friction: 100,
      }

      left = 100
      top = 200
      animate.spring(this.switch, { left, top }, springOptions)
    }
  }


  render() {
    return (
      <div style={style}>
        <h1>{this.props.playingOnTap ? 'true' : 'false'}</h1>

        <p>{this.props.text}</p>
      </div>
    )
  }
}
