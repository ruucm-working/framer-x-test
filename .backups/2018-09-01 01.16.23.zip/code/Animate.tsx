import * as React from 'react'
import {
  PropertyControls,
  ControlType,
  Frame,
  Animatable,
  animate,
} from 'framer'
import styled, { css } from 'styled-components'
import { log } from 'ruucm-util'

const AnimateFrame = styled(Frame)`
  position: absolute;
  top: 0;
  z-index: -1;
  width: 100% !important;
  height: 100% !important;

  color: sandybrown;
  background: rgba(244, 164, 96, 0.6) !important;

  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
`

// Define type of property
interface Props {
  text: string
}

export class Animate extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: 'Animate',
    animType: 'scale',
  }
  scale = Animatable(1)
  left = Animatable(0)

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: 'Text~' },
    animType: {
      type: ControlType.Enum,
      options: ['scale', 'x', 'y'],
      optionTitles: ['Scale', 'X', 'Y'],
      title: 'Animation Type',
    },
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.playing !== this.props.playing) {
      switch (this.props.animType) {
        case 'scale':
          this.scale.set(0.6)
          animate.spring(this.scale, 1)
          break
        case 'x':
          this.scale.set(2)
          animate.spring(this.scale, 1)
          break

        default:
          break
      }
    }
  }

  render() {
    return (
      <AnimateFrame
        onTap={this.props.onTap}
        scale={this.scale}
        left={this.left}
      >
        {this.props.text}
      </AnimateFrame>
    )
  }
}
