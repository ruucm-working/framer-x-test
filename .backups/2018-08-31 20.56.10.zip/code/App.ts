import { Data, animate, Override, Animatable } from 'framer'
import { log } from 'ruucm-util'

const data = Data({
  cardFocus: false,
  scale: Animatable(1),
  show: false,
  text: 'yap',
})

export const Scale: Override = () => {
  return {
    scale: data.scale,
    onTap() {
      log('scale!')
      data.cardFocus = !data.cardFocus
      log('data.cardFocus', data.cardFocus)
      log(data.cardFocus)
    },
  }
}

export const Test: Override = () => {
  return {
    focused: data.cardFocus,
    isShowing: true,
  }
}

export const actionBtn: Override = () => {
  return {
    text: data.text,
    onTap() {
      data.show = !data.show
    },
  }
}

export const Item: Override = () => {
  return {
    hey: 'aas',
    isShowing: data.show,
  }
}
