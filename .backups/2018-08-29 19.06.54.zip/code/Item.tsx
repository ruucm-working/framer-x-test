import * as React from 'react'

import {
  Frame,
  animate,
  Animatable,
  PropertyControls,
  ControlType,
  FramerAnimation,
  PropertyStore,
  RenderTarget,
} from 'framer'

import styled from 'styled-components'

// import { constants } from '../toolbox'

// const { color, animation } = constants
// const { fadeIn, fadeOut } = animation

const Wrap = styled.div``
const Label = styled.div``
const Title = styled.div``
const MainImg = styled.img`
  width: 100%;
`
const Desc = styled.div`
  background: white;
`
const CloseButton = styled.button`
  position: absolute;
`

// Define type of property
interface Props {
  title: string
  label: string
  mainImg: string
  desc: string
}

export class Item extends React.Component<Props> {
  state = {
    show: false,
  }
  // Set default properties
  static defaultProps = {
    title: '',
    label: '',
    mainImg:
      'https://cdn.vox-cdn.com/uploads/chorus_image/image/55159829/12.0.jpg',
    desc: '',
  }

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    title: { type: ControlType.String, title: 'Title' },
    label: { type: ControlType.String, title: 'Label' },
    mainImg: { type: ControlType.String, title: 'Main Image' },
    desc: { type: ControlType.String, title: 'Description' },
  }
  top = Animatable(200)
  left = Animatable(0)
  scale = Animatable(1)
  onClick = async () => {
    await animate(this.scale, 2).finished
    await animate(this.left, 200).finished
    animate(this.left, 0).finished
    animate(this.scale, 1).finished
  }
  showDetail = async () => {
    await animate(this.scale, 2).finished
    await animate(this.top, 0).finished
    this.setState({ show: true })
  }
  closeDetail = async () => {
    await animate(this.scale, 1).finished
    await animate(this.top, 200).finished
    this.setState({ show: false })
  }

  render() {
    return (
      <Wrap>
        <Frame onClick={this.showDetail}>
          {this.state.show ? (
            <CloseButton onClick={this.closeDetail}>close</CloseButton>
          ) : (
            ''
          )}
          <Label>{this.props.label}</Label>
          <Title
            dangerouslySetInnerHTML={{
              __html: this.props.title,
            }}
          />
          <Frame top={this.top} scale={this.scale}>
            <MainImg src={this.props.mainImg} />
          </Frame>
          {this.state.show ? <Desc>{this.props.desc}</Desc> : ''}
        </Frame>
      </Wrap>
    )
  }
}
