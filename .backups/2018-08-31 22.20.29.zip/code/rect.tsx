import * as React from 'react'
import { PropertyControls, ControlType, Frame } from 'framer'
import styled, { css } from 'styled-components'

const BasicFrame = styled(Frame)`
  position: absolute;
  top: 0;
  z-index: -1;
  width: 100% !important;
  height: 100% !important;

  color: sandybrown;
  background: rgba(244, 164, 96, 0.6) !important;

  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
`
const style = {
  height: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  textAlign: 'center',
  color: '#8855FF',
  background: 'rgba(136, 85, 255, 0.1)',
  overflow: 'hidden',
}

// Define type of property
interface Props {
  text: string
}

export class rect extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: 'rect',
  }

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: 'Text' },
  }

  render() {
    return <BasicFrame onTap={this.props.onTap}>{this.props.text}</BasicFrame>
  }
}
