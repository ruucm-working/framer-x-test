// WARNING: this file is auto generated, any changes will be lost
import { createDesignComponent, CanvasStore } from "framer"
const canvas = CanvasStore.shared(); // CANVAS_DATA;
export const TestCompD = createDesignComponent<{parentSize?:{width:number,height:number},width?:number,height?:number,dasf?:string}>(canvas, "id_KAjjZNQLf", {dasf:"string"}, 203,163);
